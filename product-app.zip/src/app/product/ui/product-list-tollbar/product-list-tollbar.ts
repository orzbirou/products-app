import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list-toolbar',
  imports: [],
  templateUrl: './product-list-toolbar.html',
  styleUrl: './product-list-toolbar.scss',
})
export class ProductListToolbar {

}
